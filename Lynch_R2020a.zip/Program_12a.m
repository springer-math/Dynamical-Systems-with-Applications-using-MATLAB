% Program 12a - Surface and Contour Plots. 
% Chapter 12 - Hamiltonian Systems, Lyapunov Functions, and Stability.
% Copyright Springer 2020. Stephen Lynch.

% The double-well potential (Fig. 12.5(b)).
figure;
fsize=15;
fsurf(@(x,y) -x^2/2+x^4/4+y^2/2,[-1.5,1.5],'ShowContours','on');
set(gca,'XTick',-1.5:0.5:1.5,'FontSize',fsize)
set(gca,'YTick',-1.5:0.5:1.5,'FontSize',fsize)
xlabel('x','FontSize',fsize)
ylabel('y','FontSize',fsize)
title('Surface and contour plot')

% End of Program 12a.