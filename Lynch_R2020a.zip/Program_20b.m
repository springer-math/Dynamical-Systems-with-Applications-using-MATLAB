% Program 20b - Transfer function.
% Chapter 20 - Binary Oscillator Computing.
% Copyright Springer 2020. Stephen Lynch.
% Binary oscillator half adder.
% Run Programs_20d.

function ans=Program_20b(y,m,p);
ans=1./(1+exp(m*y+p));

% End of Program 20b.