% Program 16g:Fitzhugh-Nagumo animation.
% Andronov-Hopf bifurcation of a limit cycle.
% Copyright Springer 2020.
clear
epsilon=0.01;theta=0.14;gamma=2.54;
for j=1:400; 
   F(j) = getframe;omega=(0+j*0.0005);
sys=@(t,x)[-x(1)*(x(1)-theta)*(x(1)-1)-x(2)+omega;...
           epsilon*(x(1)-gamma*x(2))]; 
[t,xs] = ode45(sys,[0 400],[0 0.1]);
plot(xs(:,1),xs(:,2));
axis([-0.4 1.2 0 0.3])
fsize=15;
set(gca,'XTick',-0.4:0.2:1.2,'FontSize',fsize);
set(gca,'YTick',0:0.1:0.3,'FontSize',fsize);
xlabel('u(t)','FontSize',fsize);
ylabel('v(t)','FontSize',fsize); 
F(j) = getframe;
end;
movie(F,5);
