% Program 16a - Groebner Bases: Monomial orders lex, dlex and drevlex.
% Chapter 16 - Local and Global Bifurcations.
% See Example 6, determining the critical points of a planar system.
% Copyright Birkhauser 2020. Stephen Lynch.

syms x y z;
p=[4*x^3-12*x*y^2+x^4+2*x^2*y^2+y^4,x+y^2-x^3];
vars=[x y z];
GBasis_lex = gbasis(p,'MonomialOrder','lexicographic')

syms x y z;
p=[4*x^3-12*x*y^2+x^4+2*x^2*y^2+y^4,x+y^2-x^3];
vars=[x y z];
GBasis_dlex = gbasis(p,'MonomialOrder','degreeLexicographic')

syms x y z;
p=[4*x^3-12*x*y^2+x^4+2*x^2*y^2+y^4,x+y^2-x^3];
vars=[x y z];
GBasis_drevlex = gbasis(p,'MonomialOrder','degreeInverseLexicographic')