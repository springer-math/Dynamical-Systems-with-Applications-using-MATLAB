% Program 08d - Determining a series solution to an ODE.
% Series solution for a van der Pol system about x=0.
% Chapter 8 - Differential Equations.
% Copyright Springer 2020. Stephen Lynch.
syms x(t)
Dx = diff(x,t);
eqn = diff(x,2) + 2*(x(t)^2-1)*diff(x) + x == 0;
S = dsolve([eqn,x(0)==5,Dx(0)==0],'ExpansionPoint',0);
display(S)