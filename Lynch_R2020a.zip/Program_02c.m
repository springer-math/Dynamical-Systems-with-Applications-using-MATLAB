% Program 02c - The Leslie Matrix - Plots.
% Chapter 2 - Linear Discrete Dynamical Systems.
% Copyright Springer 2020. Stephen Lynch.
% Commands are short enough for the Command Window.

% Program: Leslie Model Graph
% Leslie Model Age Class Populations
% See Example 4.
X=zeros(3,50);
L=[0 3 1;0.3 0 0;0 0.5 0];
X0=[1000;2000;3000];
x10=L^50*X0;
for i=1:51
    X(1:3,i)=L^(i-1)*X0;
end
Y=X';
plot(Y)
fsize=20;
title('Age Class Populations','FontSize',fsize)
set(gca,'XTick',0:10:50,'FontSize',fsize)
set(gca,'YTick',0:10000:20000,'FontSize',fsize)
axis([0 50 0 20000])
xlabel('Years','FontSize',fsize)
ylabel('Populations','FontSize',fsize)
legend('Age Class 1','Age Class 2','Age Class 3')
% End of Program 02c.